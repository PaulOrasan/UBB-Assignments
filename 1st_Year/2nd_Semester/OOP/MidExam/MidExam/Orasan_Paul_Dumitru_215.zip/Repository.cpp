#include "Repository.h"
void Repository::adaugaSerial(const SerialTV& serial) {
	lista.push_back(serial);
}