#include "Error.h"
#include <string>
std::string Error::getMessage() const {
	return message;
}